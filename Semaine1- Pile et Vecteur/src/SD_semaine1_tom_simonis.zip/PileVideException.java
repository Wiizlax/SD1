


   import java.util.*;
   import java.io.*;

    public class PileVideException extends RuntimeException {
   
       public PileVideException() {
         super();
      }
   
       public PileVideException(String s) {
         super(s);
      }
   
   }