
public class FileVideException extends RuntimeException {

		public FileVideException() {
			super();
		}

		public FileVideException(String message) {
			super(message);
		}

	}
