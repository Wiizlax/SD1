public class ListeVideException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ListeVideException() {
		super();
	}

	public ListeVideException(String message) {
		super(message);
	}

}
